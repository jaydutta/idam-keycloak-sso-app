package com.landing.app.service;


import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Properties;

import org.springframework.stereotype.Service;

import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class SSHService {

	 /**
     * Execute command on remote server via SSH
     */
    public CommandResult executeRemoteCommand(String host, int port, String username, 
                                              String password, String command) {
        JSch jsch = new JSch();
        Session session = null;
        ChannelExec channel = null;
        
        try {
            // Create SSH session
            session = jsch.getSession(username, host, port);
            session.setPassword(password);
            
            // Skip host key checking (for development only)
            Properties config = new Properties();
            config.put("StrictHostKeyChecking", "no");
            session.setConfig(config);
            
            // Connect
            session.connect(30000); // 30 second timeout
            
            // Execute command
            channel = (ChannelExec) session.openChannel("exec");
            channel.setCommand(command);
            
            // Get output streams
            InputStream inputStream = channel.getInputStream();
            InputStream errorStream = channel.getErrStream();
            
            channel.connect();
            
            // Read output
            String output = readStream(inputStream);
            String error = readStream(errorStream);
            
            int exitStatus = channel.getExitStatus();
            
            return new CommandResult(exitStatus, output, error, true);
            
        } catch (Exception e) {
            log.error("SSH command execution failed", e);
            return new CommandResult(-1, "", e.getMessage(), false);
        } finally {
            if (channel != null) channel.disconnect();
            if (session != null) session.disconnect();
        }
    }
    
    /**
     * Execute command on local server
     */
    public CommandResult executeLocalCommand(String command) {
        try {
            ProcessBuilder processBuilder = new ProcessBuilder();
            processBuilder.command("bash", "-c", command);
            
            Process process = processBuilder.start();
            
            String output = readStream(process.getInputStream());
            String error = readStream(process.getErrorStream());
            
            int exitCode = process.waitFor();
            
            return new CommandResult(exitCode, output, error, true);
            
        } catch (Exception e) {
            log.error("Local command execution failed", e);
            return new CommandResult(-1, "", e.getMessage(), false);
        }
    }
    
    private String readStream(InputStream stream) throws Exception {
        BufferedReader reader = new BufferedReader(
            new InputStreamReader(stream, StandardCharsets.UTF_8));
        
        StringBuilder output = new StringBuilder();
        String line;
        
        while ((line = reader.readLine()) != null) {
            output.append(line).append("\n");
        }
        
        return output.toString();
    }
    
    /**
     * Command execution result
     */
    public static class CommandResult {
        private int exitCode;
        private String output;
        private String error;
        private boolean success;
        
        public CommandResult(int exitCode, String output, String error, boolean success) {
            this.exitCode = exitCode;
            this.output = output;
            this.error = error;
            this.success = success;
        }
        
        // Getters
        public int getExitCode() { return exitCode; }
        public String getOutput() { return output; }
        public String getError() { return error; }
        public boolean isSuccess() { return success; }
    }
}
