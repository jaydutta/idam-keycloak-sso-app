package com.landing.app.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.landing.app.service.SSHService;
import com.landing.app.service.SSHService.CommandResult;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/api/cli")
@PreAuthorize("hasRole('eniq_administrator')") // Only admins can execute commands
public class SSHCLIController {

    @Autowired
    private SSHService sshService;
    
    /**
     * Execute command on local server
     */
    @PostMapping("/execute/local")
    public ResponseEntity<Map<String, Object>> executeLocal(@RequestBody CommandRequest request) {
        log.info("Executing local command: {}", request.getCommand());
        
        // Security: Validate command (prevent dangerous commands)
        if (!isCommandSafe(request.getCommand())) {
            return ResponseEntity.badRequest().body(
                createErrorResponse("Command not allowed for security reasons")
            );
        }
        
        CommandResult result = sshService.executeLocalCommand(request.getCommand());
        
        return ResponseEntity.ok(createSuccessResponse(result));
    }
    
    /**
     * Execute command on remote server via SSH
     */
    @PostMapping("/execute/remote")
    public ResponseEntity<Map<String, Object>> executeRemote(@RequestBody SSHCommandRequest request) {
        log.info("Executing remote command on {}: {}", request.getHost(), request.getCommand());
        
        // Security: Validate command
        if (!isCommandSafe(request.getCommand())) {
            return ResponseEntity.badRequest().body(
                createErrorResponse("Command not allowed for security reasons")
            );
        }
        
        CommandResult result = sshService.executeRemoteCommand(
            request.getHost(),
            request.getPort() != null ? request.getPort() : 22,
            request.getUsername(),
            request.getPassword(),
            request.getCommand()
        );
        
        return ResponseEntity.ok(createSuccessResponse(result));
    }
    
    /**
     * Get command history (placeholder - implement with database)
     */
    @GetMapping("/history")
    public ResponseEntity<Map<String, Object>> getHistory() {
        // TODO: Implement command history storage and retrieval
        Map<String, Object> response = new HashMap<>();
        response.put("history", new String[]{});
        return ResponseEntity.ok(response);
    }
    
    /**
     * Validate command safety
     */
    private boolean isCommandSafe(String command) {
        // Blacklist dangerous commands
        String[] dangerousCommands = {
            "rm -rf /",
            "mkfs",
            "dd if=/dev/zero",
            "> /dev/sda",
            "fork bomb",
            ":(){ :|:& };:",
            "chmod -R 777 /",
            "chown -R"
        };
        
        String lowerCommand = command.toLowerCase();
        for (String dangerous : dangerousCommands) {
            if (lowerCommand.contains(dangerous.toLowerCase())) {
                return false;
            }
        }
        
        return true;
    }
    
    private Map<String, Object> createSuccessResponse(CommandResult result) {
        Map<String, Object> response = new HashMap<>();
        response.put("success", result.isSuccess());
        response.put("exitCode", result.getExitCode());
        response.put("output", result.getOutput());
        response.put("error", result.getError());
        return response;
    }
    
    private Map<String, Object> createErrorResponse(String message) {
        Map<String, Object> response = new HashMap<>();
        response.put("success", false);
        response.put("error", message);
        return response;
    }
    
    /**
     * Request DTOs
     */
    public static class CommandRequest {
        private String command;
        
        public String getCommand() { return command; }
        public void setCommand(String command) { this.command = command; }
    }
    
    public static class SSHCommandRequest extends CommandRequest {
        private String host;
        private Integer port;
        private String username;
        private String password;
        
        public String getHost() { return host; }
        public void setHost(String host) { this.host = host; }
        
        public Integer getPort() { return port; }
        public void setPort(Integer port) { this.port = port; }
        
        public String getUsername() { return username; }
        public void setUsername(String username) { this.username = username; }
        
        public String getPassword() { return password; }
        public void setPassword(String password) { this.password = password; }
    }
}