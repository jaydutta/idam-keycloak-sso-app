import React, { useState, useRef, useEffect } from 'react';
import axios from 'axios';
import '../styles/Terminal.css';

function Terminal() {
  const [command, setCommand] = useState('');
  const [history, setHistory] = useState([]);
  const [commandHistory, setCommandHistory] = useState([]);
  const [historyIndex, setHistoryIndex] = useState(-1);
  const inputRef = useRef(null);
  const terminalRef = useRef(null);

  useEffect(() => {
    // Auto-scroll to bottom
    if (terminalRef.current) {
      terminalRef.current.scrollTop = terminalRef.current.scrollHeight;
    }
  }, [history]);

  const executeCommand = async (cmd) => {
    if (!cmd.trim()) return;

    // Add command to history
    setHistory(prev => [...prev, { type: 'command', text: `$ ${cmd}` }]);
    setCommandHistory(prev => [...prev, cmd]);
    setHistoryIndex(-1);

    try {
      // Execute local command
      const response = await axios.post('/api/cli/execute/local', {
        command: cmd
      }, {
        withCredentials: true
      });

      const result = response.data;

      // Add output to history
      if (result.success) {
        if (result.output) {
          setHistory(prev => [...prev, { 
            type: 'output', 
            text: result.output 
          }]);
        }
        if (result.error) {
          setHistory(prev => [...prev, { 
            type: 'error', 
            text: result.error 
          }]);
        }
      } else {
        setHistory(prev => [...prev, { 
          type: 'error', 
          text: result.error || 'Command failed' 
        }]);
      }
    } catch (error) {
      setHistory(prev => [...prev, { 
        type: 'error', 
        text: `Error: ${error.response?.data?.error || error.message}` 
      }]);
    }

    setCommand('');
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter') {
      executeCommand(command);
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      if (commandHistory.length > 0) {
        const newIndex = historyIndex + 1;
        if (newIndex < commandHistory.length) {
          setHistoryIndex(newIndex);
          setCommand(commandHistory[commandHistory.length - 1 - newIndex]);
        }
      }
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      if (historyIndex > 0) {
        const newIndex = historyIndex - 1;
        setHistoryIndex(newIndex);
        setCommand(commandHistory[commandHistory.length - 1 - newIndex]);
      } else {
        setHistoryIndex(-1);
        setCommand('');
      }
    }
  };

  const clearTerminal = () => {
    setHistory([]);
  };

  return (
    <div className="terminal-container">
      <div className="terminal-header">
        <div className="terminal-title">Linux Terminal</div>
        <button onClick={clearTerminal} className="clear-btn">Clear</button>
      </div>
      
      <div className="terminal-body" ref={terminalRef}>
        <div className="terminal-welcome">
          Welcome to Web Terminal. Type 'help' for available commands.
        </div>
        
        {history.map((item, index) => (
          <div key={index} className={`terminal-line terminal-${item.type}`}>
            {item.text}
          </div>
        ))}
        
        <div className="terminal-input-line">
          <span className="terminal-prompt">$ </span>
          <input
            ref={inputRef}
            type="text"
            value={command}
            onChange={(e) => setCommand(e.target.value)}
            onKeyDown={handleKeyDown}
            className="terminal-input"
            autoFocus
            placeholder="Enter command..."
          />
        </div>
      </div>
    </div>
  );
}

export default Terminal;