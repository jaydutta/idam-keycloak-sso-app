import React, { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import '../styles/LandingPage.css';

function LandingPage({ user }) {
  const location = useLocation();
  const [errorMessage, setErrorMessage] = useState('');
  const [authorizedApps, setAuthorizedApps] = useState([]);

  useEffect(() => {
    // Parse query parameters for error messages and authorized apps
    const params = new URLSearchParams(location.search);
    const error = params.get('error');
    const apps = params.get('authorized_apps');

    if (error) {
      setErrorMessage(decodeURIComponent(error));
    }

    if (apps) {
      const appsList = decodeURIComponent(apps).split(',').map(app => app.trim());
      setAuthorizedApps(appsList);
      console.log('Authorized apps from backend:', appsList);
    }
  }, [location]);

  const hasRole = (role) => {
    if (!user?.roles) return false;
    console.log('Checking role:', role, 'User roles:', user.roles);
    return user.roles.some(r => {
      const authority = typeof r === 'string' ? r : r.authority;
      return authority === `ROLE_${role}` || authority === role;
    });
  };

  const isAdmin = () => hasRole('admin') || hasRole('ENIQ_Administrator') || hasRole('eniq_administrator');
  const isFileUploadUser = () => hasRole('file-upload-user') || hasRole('fileuploaduser') || hasRole('file_user') || hasRole('eniqadmin_ui');
  const isReportUser = () => hasRole('report-user') || hasRole('reportuser') || hasRole('report_user') || hasRole('netan_ui');

  // If we have authorized apps from query params, use those; otherwise use role-based check
  const canAccessFileUpload = () => {
    if (authorizedApps.length > 0) {
      return authorizedApps.includes('File Upload');
    }
    return isAdmin() || isFileUploadUser();
  };

  const canAccessReportGeneration = () => {
    if (authorizedApps.length > 0) {
      return authorizedApps.includes('Report Generation');
    }
    return isAdmin() || isReportUser();
  };

  const navigateToFileApp = () => {
    // For File Upload app (port 3002)
    // Use the redirect endpoint with target_url parameter
    const targetUrl = encodeURIComponent('http://localhost:3002');
    window.location.href = `http://localhost:8092/redirect?target_url=${targetUrl}`;
  };

  const navigateToReportApp = () => {
    // For Report Generation app (port 3001)
    // Use the redirect endpoint with target_url parameter
    const targetUrl = encodeURIComponent('http://localhost:3001');
    window.location.href = `http://localhost:8092/redirect?target_url=${targetUrl}`;
  };

  const openCLITerminal = () => {
    // Navigate to CLI Terminal page
    window.location.href = '/terminal';
  };

  const dismissError = () => {
    setErrorMessage('');
    // Clear query parameters from URL
    window.history.replaceState({}, document.title, window.location.pathname);
  };

  return (
    <div className="landing-page">
      {/* Error Message Banner */}
      {errorMessage && (
        <div className="error-banner">
          <div className="error-content">
            <div className="error-icon">⚠️</div>
            <div className="error-text">
              <strong>Access Denied</strong>
              <p>{errorMessage}</p>
            </div>
            <button className="error-dismiss" onClick={dismissError}>
              ×
            </button>
          </div>
        </div>
      )}

      <div className="welcome-section">
        <h1>Welcome to ENIQ Landing Page</h1>
        <p className="welcome-text">
          Hello, <strong>{user?.firstName || user?.username}</strong>! 
          Select an application to continue:
        </p>
      </div>

      <div className="apps-grid">
        {/* Admin Dashboard Card - Only for Admins */}
        {isAdmin() && (
          <div className="app-card admin-card">
            <div className="app-icon">👨‍💼</div>
            <h2>Admin Dashboard</h2>
            <p>Manage users, roles, and system settings</p>
            <button 
              onClick={() => window.location.href = '/users'}
              className="btn-primary"
            >
              Open Dashboard
            </button>
          </div>
        )}

        {/* CLI Terminal Card - Only for Admins */}
        {isAdmin() && (
          <div className="app-card terminal-card">
            <div className="app-icon">💻</div>
            <h2>CLI Terminal</h2>
            <p>Access command line interface via browser</p>
            <button 
              onClick={openCLITerminal}
              className="btn-primary"
            >
              Open Terminal
            </button>
          </div>
        )}

        {/* File Upload App - ENIQ Admin UI */}
        {canAccessFileUpload() && (
          <div className="app-card file-card">
            <div className="app-icon">📁</div>
            <h2>ENIQ Admin UI</h2>
            <p>Upload and manage files for ENIQ system</p>
            <button 
              onClick={navigateToFileApp}
              className="btn-primary"
            >
              Open ENIQ Admin UI
            </button>
          </div>
        )}

        {/* Report Generation App - NetAn UI */}
        {canAccessReportGeneration() && (
          <div className="app-card report-card">
            <div className="app-icon">📊</div>
            <h2>NetAn UI</h2>
            <p>Generate and view network analysis reports</p>
            <button 
              onClick={navigateToReportApp}
              className="btn-primary"
            >
              Open NetAn UI
            </button>
          </div>
        )}

        {/* Profile Card - Available to all */}
        <div className="app-card profile-card">
          <div className="app-icon">👤</div>
          <h2>My Profile</h2>
          <p>View and update your profile information</p>
          <button 
            onClick={() => window.location.href = '/profile'}
            className="btn-primary"
          >
            View Profile
          </button>
        </div>

        {/* No Access Message */}
        {!isAdmin() && !canAccessReportGeneration() && !canAccessFileUpload() && (
          <div className="no-access">
            <div className="no-access-icon">🔒</div>
            <h3>Limited Access</h3>
            <p>You currently have access to your profile only.</p>
            <p>Contact your administrator for additional permissions.</p>
          </div>
        )}

        {/* Show authorized apps when error is present */}
        {errorMessage && authorizedApps.length > 0 && (
          <div className="authorized-apps-info">
            <h4>Your Authorized Applications:</h4>
            <ul>
              {authorizedApps.map((app, index) => (
                <li key={index}>
                  <span className="app-badge">✓ {app}</span>
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>

      <div className="user-info">
        <h3>Your Account Information</h3>
        <div className="info-grid">
          <div className="info-item">
            <span className="info-label">Username:</span>
            <span className="info-value">{user?.username}</span>
          </div>
          <div className="info-item">
            <span className="info-label">Email:</span>
            <span className="info-value">{user?.email}</span>
          </div>
          <div className="info-item">
            <span className="info-label">Full Name:</span>
            <span className="info-value">
              {user?.firstName} {user?.lastName}
            </span>
          </div>
          <div className="info-item">
            <span className="info-label">Roles:</span>
            <span className="info-value roles-display">
              {user?.roles?.map((r, index) => {
                const authority = typeof r === 'string' ? r : r.authority;
                const roleName = authority.replace('ROLE_', '');
                return (
                  <span key={index} className="role-badge">
                    {roleName}
                  </span>
                );
              })}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}

export default LandingPage;
