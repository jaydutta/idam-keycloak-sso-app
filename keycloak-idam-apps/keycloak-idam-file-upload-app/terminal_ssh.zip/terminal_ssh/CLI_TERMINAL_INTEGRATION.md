# CLI Terminal Integration Guide

## Overview

This guide shows how to integrate the CLI Terminal button into your Landing Page.

---

## Files Provided

1. **LandingPage_updated.jsx** - Landing page with CLI Terminal button
2. **LandingPage_updated.css** - Updated styles with terminal card
3. **Terminal.jsx** - CLI Terminal component
4. **Terminal.css** - Terminal component styles

---

## Step 1: Update Landing Page

### Replace Your Files

```bash
# In your frontend project
cd src/components
cp LandingPage_updated.jsx LandingPage.jsx

cd ../styles
cp LandingPage_updated.css LandingPage.css
```

---

## Step 2: Add Terminal Component

### Create Terminal Component

```bash
# Create Terminal component
cd src/components
# Copy Terminal.jsx here

# Create Terminal CSS
cd ../styles
# Copy Terminal.css here
```

---

## Step 3: Add Route for Terminal

### Update App.jsx (or your router file)

```jsx
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import LandingPage from './components/LandingPage';
import Terminal from './components/Terminal';
// ... other imports

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<LandingPage user={user} />} />
        <Route path="/terminal" element={<Terminal />} />
        {/* ... other routes */}
      </Routes>
    </Router>
  );
}

export default App;
```

---

## Step 4: Verify Backend API is Ready

### Check if CLI Controller Exists

Your backend should have:
```
/api/cli/execute/local - POST endpoint for executing commands
```

If not, add the CLIController from the WEB_SSH_CLI_IMPLEMENTATION.md guide.

### Quick Backend Setup

**Add to pom.xml**:
```xml
<dependency>
    <groupId>com.jcraft</groupId>
    <artifactId>jsch</artifactId>
    <version>0.1.55</version>
</dependency>
```

**Add files** (from previous guide):
- `SSHService.java`
- `CLIController.java`

---

## Step 5: Test the Integration

### Test Flow

1. **Login as Administrator**
   ```
   - Login with eniq_administrator role
   - Should see "CLI Terminal" card on landing page
   ```

2. **Click "Open Terminal"**
   ```
   - Should navigate to /terminal
   - Terminal interface should load
   ```

3. **Execute Commands**
   ```
   - Type: help
   - Type: ls -la
   - Type: pwd
   - Type: uptime
   ```

4. **Verify Only Admins See It**
   ```
   - Login as file_user (non-admin)
   - CLI Terminal card should NOT appear
   ```

---

## Features

### CLI Terminal Capabilities

✅ **Execute Linux Commands**:
- ls, pwd, cat, grep, etc.
- df -h, free -m, ps aux
- Any safe Linux command

✅ **Command History**:
- Use ↑ ↓ arrows to navigate
- Stores command history in session

✅ **Special Commands**:
- `help` - Show help
- `clear` - Clear terminal

✅ **Error Handling**:
- Shows authentication errors
- Shows command execution errors
- Displays permission denied messages

✅ **Responsive Design**:
- Works on desktop and mobile
- Auto-scrolls to bottom
- Professional terminal styling

---

## Security

### Admin-Only Access

The terminal is only visible to users with:
- `eniq_administrator` role
- `admin` role
- `ENIQ_Administrator` role

### Backend Protection

The `/api/cli/execute/local` endpoint should have:

```java
@PreAuthorize("hasRole('eniq_administrator')")
public class CLIController {
    // Only administrators can execute commands
}
```

### Command Validation

Backend validates commands to prevent:
- `rm -rf /`
- `mkfs`
- Other dangerous commands

---

## Customization

### Change Terminal Colors

In `Terminal.css`:

```css
.terminal-body {
  color: #00ff00; /* Change to your preferred color */
  background: #1e1e1e; /* Change background */
}

.terminal-prompt {
  color: #00ff00; /* Change prompt color */
}
```

### Change Terminal Icon

In `LandingPage_updated.jsx`:

```jsx
<div className="app-icon">💻</div> 
// Change to: 🖥️ ⌨️ 🔧 or any other emoji
```

### Add More Commands

In `Terminal.jsx`, add to the `help` command:

```javascript
if (cmd.trim().toLowerCase() === 'help') {
  setHistory(prev => [...prev, { 
    type: 'output', 
    text: `Available Commands:
- help: Show this help message
- clear: Clear the terminal
- mycommand: Your custom command
- Any Linux command` 
  }]);
}
```

---

## API Integration Points

### Frontend → Backend

```javascript
// Terminal.jsx calls this endpoint
POST http://localhost:8092/api/cli/execute/local
Body: { "command": "ls -la" }
Response: {
  "success": true,
  "exitCode": 0,
  "output": "file1\nfile2\n",
  "error": ""
}
```

### Required Headers

```javascript
{
  'Content-Type': 'application/json',
  withCredentials: true  // For session cookies
}
```

---

## Troubleshooting

### Issue 1: Terminal Button Not Showing

**Check**:
- User has admin role
- LandingPage.jsx has been updated
- `isAdmin()` function is working

**Solution**:
```javascript
// Add console.log to debug
console.log('User roles:', user?.roles);
console.log('Is admin:', isAdmin());
```

### Issue 2: Cannot Connect to Server

**Error**: "Cannot connect to server"

**Solutions**:
1. Check backend is running
2. Verify API endpoint URL
3. Check CORS configuration
4. Test endpoint directly:
```bash
curl -X POST http://localhost:8092/api/cli/execute/local \
  -H "Content-Type: application/json" \
  -d '{"command": "pwd"}'
```

### Issue 3: Permission Denied

**Error**: "Access denied. You need administrator privileges"

**Solutions**:
1. Verify user has admin role in Keycloak
2. Check @PreAuthorize annotation on controller
3. Verify Spring Security configuration

### Issue 4: Commands Not Executing

**Check**:
1. Backend SSHService exists
2. Command validation is not blocking
3. Check backend logs for errors

---

## File Structure

```
frontend/
├── src/
│   ├── components/
│   │   ├── LandingPage.jsx (UPDATED)
│   │   └── Terminal.jsx (NEW)
│   ├── styles/
│   │   ├── LandingPage.css (UPDATED)
│   │   └── Terminal.css (NEW)
│   └── App.jsx (UPDATE - add route)
│
backend/
├── src/main/java/com/fileupload/app/
│   ├── controller/
│   │   └── CLIController.java
│   └── service/
│       └── SSHService.java
```

---

## Complete Integration Checklist

### Frontend

- [ ] Copy LandingPage_updated.jsx to LandingPage.jsx
- [ ] Copy LandingPage_updated.css to LandingPage.css
- [ ] Add Terminal.jsx component
- [ ] Add Terminal.css styles
- [ ] Add /terminal route in App.jsx
- [ ] Test CLI Terminal button appears for admins
- [ ] Test CLI Terminal button hidden for non-admins

### Backend

- [ ] Add JSch dependency to pom.xml
- [ ] Add SSHService.java
- [ ] Add CLIController.java
- [ ] Configure @PreAuthorize for admin-only access
- [ ] Test /api/cli/execute/local endpoint
- [ ] Verify command validation works

### Testing

- [ ] Login as administrator → CLI Terminal visible
- [ ] Login as file_user → CLI Terminal not visible
- [ ] Click "Open Terminal" → Navigates to /terminal
- [ ] Execute "help" command → Shows help
- [ ] Execute "ls -la" → Shows directory listing
- [ ] Execute "clear" → Clears terminal
- [ ] Use ↑ arrow → Shows previous command
- [ ] Test on mobile → Responsive layout works

---

## Summary

The CLI Terminal integration is complete! 

**What You Get**:
✅ Professional CLI terminal in browser
✅ Admin-only access
✅ Command execution via REST API
✅ Command history navigation
✅ Error handling
✅ Responsive design
✅ Seamless integration with landing page

**Next Steps**:
1. Copy the updated files
2. Add the route
3. Ensure backend API is ready
4. Test with admin and non-admin users

Enjoy your web-based CLI terminal! 🚀
