package com.fileupload.app.config;

import org.springframework.security.oauth2.client.registration.ClientRegistrationRepository;
import org.springframework.security.oauth2.client.web.DefaultOAuth2AuthorizationRequestResolver;
import org.springframework.security.oauth2.client.web.OAuth2AuthorizationRequestResolver;
import org.springframework.security.oauth2.core.endpoint.OAuth2AuthorizationRequest;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class CustomAuthorizationRequestResolver implements OAuth2AuthorizationRequestResolver {

    private final OAuth2AuthorizationRequestResolver defaultResolver;
    private final TargetUrlStore targetUrlStore;
    public static final String TARGET_URL_SESSION_ATTRIBUTE = "POST_LOGIN_TARGET_URL";

    public CustomAuthorizationRequestResolver(
            ClientRegistrationRepository clientRegistrationRepository,
            TargetUrlStore targetUrlStore) {
        this.defaultResolver = new DefaultOAuth2AuthorizationRequestResolver(
            clientRegistrationRepository, "/oauth2/authorization");
        this.targetUrlStore = targetUrlStore;
    }

    @Override
    public OAuth2AuthorizationRequest resolve(HttpServletRequest request) {
        OAuth2AuthorizationRequest authorizationRequest = defaultResolver.resolve(request);
        return customizeAuthorizationRequest(authorizationRequest, request);
    }

    @Override
    public OAuth2AuthorizationRequest resolve(HttpServletRequest request, String clientRegistrationId) {
        OAuth2AuthorizationRequest authorizationRequest = defaultResolver.resolve(request, clientRegistrationId);
        return customizeAuthorizationRequest(authorizationRequest, request);
    }

    private OAuth2AuthorizationRequest customizeAuthorizationRequest(
            OAuth2AuthorizationRequest authorizationRequest, HttpServletRequest request) {
        
        if (authorizationRequest == null) {
            return null;
        }

        // Check if there's a target URL in the session
        HttpSession session = request.getSession(false);
        if (session != null) {
            String targetUrl = (String) session.getAttribute(TARGET_URL_SESSION_ATTRIBUTE);
            if (targetUrl != null && !targetUrl.isEmpty()) {
                // Store the target URL in our cache using the OAuth2 state as the key
                String state = authorizationRequest.getState();
                log.info("Storing target URL in cache with state key: {}", state);
                targetUrlStore.store(state, targetUrl);
            }
        }

        return authorizationRequest;
    }
}