package com.fileupload.app.controller;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class RedirectController {

	@Value("${app.landing-page-url}")
	private String landingPageUrl;

	public static final String TARGET_URL_SESSION_ATTRIBUTE = "POST_LOGIN_TARGET_URL";

	/**
	 * This endpoint handles redirects with target URLs Usage:
	 * http://localhost:8091/redirect?target_url=http://localhost:3001
	 */
	@GetMapping("/redirect")
	public void redirect(@RequestParam(required = false) String target_url, HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		System.out.println("=== RedirectController Redirect Logic ===  target_url " + target_url);
		if (target_url != null && !target_url.isEmpty()) {
			log.info("Storing target URL in session: {}", target_url);

			// Store the target URL in the session so it survives the OAuth2 flow
			HttpSession session = request.getSession(true);
			System.out.println("=== RedirectController Redirect Logic ===  session " + session);
			System.out.println(
					"=== RedirectController Redirect Logic ===  session.getAccessor() " + session.getAccessor());
			session.setAttribute(TARGET_URL_SESSION_ATTRIBUTE, target_url);

			log.info("Redirecting to OAuth2 login");
			response.sendRedirect("/oauth2/authorization/keycloak");
		} else {
			log.info("No target URL provided, redirecting to landing page");
			response.sendRedirect(landingPageUrl);
		}
	}
}