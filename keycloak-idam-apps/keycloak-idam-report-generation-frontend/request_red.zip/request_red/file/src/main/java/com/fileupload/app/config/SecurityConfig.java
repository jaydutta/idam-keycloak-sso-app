package com.fileupload.app.config;

import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.oauth2.client.oidc.userinfo.OidcUserRequest;
import org.springframework.security.oauth2.client.oidc.userinfo.OidcUserService;
import org.springframework.security.oauth2.client.userinfo.OAuth2UserService;
import org.springframework.security.oauth2.core.oidc.user.DefaultOidcUser;
import org.springframework.security.oauth2.core.oidc.user.OidcUser;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.jwt.NimbusJwtDecoder;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationConverter;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.security.web.authentication.SavedRequestAwareAuthenticationSuccessHandler;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Configuration
@EnableWebSecurity
@EnableMethodSecurity
public class SecurityConfig {

    @Value("${spring.security.oauth2.resourceserver.jwt.jwk-set-uri}")
    private String jwkSetUri;

    @Value("${app.frontend-url}")
    private String frontendUrl;
    
    @Value("${app.landing-page-url}")
    private String landingPageUrl;
 
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            .cors(cors -> cors.configurationSource(corsConfigurationSource()))
            .csrf(csrf -> csrf.disable())
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/api/public/**", "/actuator/**", "/error", "/login/**", "/oauth2/**", "/redirect").permitAll()
                .anyRequest().authenticated()
            )
            .addFilterBefore(statePreservingFilter, org.springframework.security.oauth2.client.web.OAuth2LoginAuthenticationFilter.class)
            .oauth2Login(oauth2 -> oauth2
                .authorizationEndpoint(authorization -> 
                    authorization.authorizationRequestResolver(
                        customAuthorizationRequestResolver()))
                .userInfoEndpoint(userInfo -> userInfo.oidcUserService(oidcUserService()))
                // Use custom success handler for role-based redirection
                .successHandler(roleBasedAuthenticationSuccessHandler())
                .failureUrl("/login?error")
            )
            .oauth2ResourceServer(oauth2 -> oauth2
                .jwt(jwt -> jwt.jwtAuthenticationConverter(jwtAuthenticationConverter()))
            )
            .logout(logout -> logout
                .logoutSuccessUrl(landingPageUrl)
                .invalidateHttpSession(true)
                .clearAuthentication(true)
                .deleteCookies("JSESSIONID")
            );
        
        return http.build();
    }
    
    @Bean
    public CustomAuthorizationRequestResolver customAuthorizationRequestResolver() {
        return new CustomAuthorizationRequestResolver(clientRegistrationRepository, targetUrlStore);
    }
    
    @org.springframework.beans.factory.annotation.Autowired
    private org.springframework.security.oauth2.client.registration.ClientRegistrationRepository clientRegistrationRepository;
    
    @org.springframework.beans.factory.annotation.Autowired
    private StatePreservingFilter statePreservingFilter;
    
    @org.springframework.beans.factory.annotation.Autowired
    private TargetUrlStore targetUrlStore;

    @Bean
    public AuthenticationSuccessHandler roleBasedAuthenticationSuccessHandler() {
        return new AuthenticationSuccessHandler() {
            @Override
            public void onAuthenticationSuccess(HttpServletRequest request, 
                                              HttpServletResponse response,
                                              Authentication authentication) 
                    throws IOException, ServletException {
                
                Collection<? extends GrantedAuthority> authorities = authentication.getAuthorities();
                
                log.info("=== Role-Based Redirect Logic ===");
                log.info("User: {}", authentication.getName());
                log.info("Authorities: {}", authorities);
                
                // Check if there's a saved request (where the user originally tried to go)
                String savedRequestUrl = getSavedRequestUrl(request);
                log.info("Saved request URL: {}", savedRequestUrl);
                
                String redirectUrl = determineRedirectUrl(authorities, savedRequestUrl);
                
                log.info("Redirecting to: {}", redirectUrl);
                log.info("================================");
                
                response.sendRedirect(redirectUrl);
            }
            
            private String getSavedRequestUrl(HttpServletRequest request) {
                // Try to get state from session (stored by StatePreservingFilter)
                HttpSession session = request.getSession(false);
                System.out.println(":: SecurityConfig getSavedRequestUrl() ===  request$$$$$$ "+request);
                if (session != null) {
                	System.out.println(":: SecurityConfig getSavedRequestUrl() ===  session "+session);
                    String stateKey = (String) session.getAttribute("OAUTH2_STATE_KEY");
                    System.out.println(":: SecurityConfig getSavedRequestUrl() ===  stateKey "+stateKey);
                    if (stateKey != null) {
                        log.info("Found OAuth2 state in session: {}", stateKey);
                        System.out.println(":: SecurityConfig getSavedRequestUrl() if Block>>>>>  stateKey "+stateKey);
                        // Retrieve target URL from cache using the state
                        String targetUrl = targetUrlStore.retrieve(stateKey);
                        System.out.println(":: SecurityConfig getSavedRequestUrl() ===  targetUrl "+targetUrl);
                        if (targetUrl != null && !targetUrl.isEmpty()) {
                            log.info("Retrieved target URL from cache: {}", targetUrl);
                            System.out.println(":: SecurityConfig getSavedRequestUrl() if+++++ targetUrl "+targetUrl);
                            session.removeAttribute("OAUTH2_STATE_KEY");
                            return targetUrl;
                        }
                    }
                    
                    // Fall back to original session attribute
                    String targetUrl = (String) session.getAttribute("POST_LOGIN_TARGET_URL");
                    if (targetUrl != null && !targetUrl.isEmpty()) {
                        log.info("Found target URL in session: {}", targetUrl);
                        session.removeAttribute("POST_LOGIN_TARGET_URL");
                        return targetUrl;
                    }
                }
                System.out.println(":: SecurityConfig getSavedRequestUrl() ===  request############### "+request);
                // Check if there's a saved request in the session
                var savedRequest = (org.springframework.security.web.savedrequest.SavedRequest) 
                    request.getSession().getAttribute("SPRING_SECURITY_SAVED_REQUEST");
                System.out.println(":: SecurityConfig getSavedRequestUrl() ===  savedRequest "+savedRequest);
                if (savedRequest != null) {
                    String requestUrl = savedRequest.getRedirectUrl();
                    log.info("Found saved request: {}", requestUrl);
                    System.out.println(":: SecurityConfig getSavedRequestUrl() ===  requestUrl "+requestUrl);
                    return requestUrl;
                }
                
                // Check referer header as fallback
                String referer = request.getHeader("Referer");
                if (referer != null && !referer.contains("/login") && !referer.contains("/oauth2")) {
                    log.info("Using referer: {}", referer);
                    return referer;
                }
                
                return null;
            }
            
            private String determineRedirectUrl(Collection<? extends GrantedAuthority> authorities, 
                                               String savedRequestUrl) {
                
                // If user has admin role
                boolean isAdmin = hasRole(authorities, "ROLE_admin") || 
                                 hasRole(authorities, "ROLE_ADMIN") ||
                                 hasRole(authorities, "ENIQ_Administrator") || 
                                 hasRole(authorities, "ROLE_ENIQ_Administrator") ||
                                 hasRole(authorities, "eniq_administrator") || 
                                 hasRole(authorities, "ROLE_eniq_administrator");
                
                // If admin and there's a saved request, redirect there
                if (isAdmin && savedRequestUrl != null) {
                    log.info("Admin with saved request - redirecting to: {}", savedRequestUrl);
                    return savedRequestUrl;
                }
                
                // If admin without saved request, go to landing page
                if (isAdmin) {
                    log.info("Admin detected - redirecting to landing page");
                    return landingPageUrl;
                }
                
                // Check for report user role
                if (hasRole(authorities, "ROLE_report_user") || 
                    hasRole(authorities, "netan_ui") ||
                    hasRole(authorities, "report_user") ||
                    hasRole(authorities, "ROLE_netan_ui")) { 
                    log.info("Report user detected - redirecting to report app");
                    return "http://localhost:3001";
                }
                
                // Check for file upload user role
                if (hasRole(authorities, "ROLE_file_user") || 
                    hasRole(authorities, "eniqadmin_ui") ||
                    hasRole(authorities, "file_user") ||
                    hasRole(authorities, "ROLE_eniqadmin_ui")) { 
                    log.info("File user detected - redirecting to file upload app");
                    return "http://localhost:3002";
                }
                
                // Default: redirect to landing page
                log.info("No specific role found - redirecting to landing page");
                return landingPageUrl;
            }
            
            private boolean hasRole(Collection<? extends GrantedAuthority> authorities, String role) {
                return authorities.stream()
                    .anyMatch(auth -> auth.getAuthority().equalsIgnoreCase(role));
            }
        };
    }

    @Bean
    public OAuth2UserService<OidcUserRequest, OidcUser> oidcUserService() {
        final OidcUserService delegate = new OidcUserService();

        return userRequest -> {
            try {
                OidcUser oidcUser = delegate.loadUser(userRequest);
                
                Set<GrantedAuthority> authorities = new HashSet<>();
                extractRolesFromClaims(oidcUser.getClaims(), authorities);
                
                if (authorities.isEmpty()) {
                    authorities.add(new SimpleGrantedAuthority("ROLE_USER"));
                }
                
                log.info("User {} authenticated with authorities: {}", 
                        oidcUser.getPreferredUsername(), authorities);
                
                return new DefaultOidcUser(authorities, oidcUser.getIdToken(), oidcUser.getUserInfo());
            } catch (Exception e) {
                log.error("Failed to load user", e);
                throw e;
            }
        };
    }

    private void extractRolesFromClaims(Map<String, Object> claims, Set<GrantedAuthority> authorities) {
        try {
            log.debug("Available claims: {}", claims.keySet());
            
            // Extract from realm_access
            Object realmAccessObj = claims.get("realm_access");
            if (realmAccessObj instanceof Map) {
                @SuppressWarnings("unchecked")
                Map<String, Object> realmAccess = (Map<String, Object>) realmAccessObj;
                Object rolesObj = realmAccess.get("roles");
                
                if (rolesObj instanceof List) {
                    @SuppressWarnings("unchecked")
                    List<String> roles = (List<String>) rolesObj;
                    log.debug("Found realm_access roles: {}", roles);
                    
                    roles.stream()
                        .filter(role -> !role.startsWith("default-") && 
                                      !role.startsWith("offline_") && 
                                      !role.startsWith("uma_"))
                        .map(role -> new SimpleGrantedAuthority("ROLE_" + role))
                        .forEach(authorities::add);
                }
            }
            
            log.debug("Final extracted authorities: {}", authorities);
        } catch (Exception e) {
            log.error("Failed to extract roles", e);
        }
    }

    @Bean
    public JwtDecoder jwtDecoder() {
        return NimbusJwtDecoder.withJwkSetUri(jwkSetUri).build();
    }

    private JwtAuthenticationConverter jwtAuthenticationConverter() {
        JwtAuthenticationConverter converter = new JwtAuthenticationConverter();
        
        converter.setJwtGrantedAuthoritiesConverter(jwt -> {
            Set<GrantedAuthority> authorities = new HashSet<>();
            
            try {
                Map<String, Object> realmAccess = jwt.getClaim("realm_access");
                if (realmAccess != null && realmAccess.get("roles") != null) {
                    @SuppressWarnings("unchecked")
                    List<String> roles = (List<String>) realmAccess.get("roles");
                    
                    roles.stream()
                        .filter(role -> !role.startsWith("default-") && 
                                      !role.startsWith("offline_") && 
                                      !role.startsWith("uma_"))
                        .map(role -> new SimpleGrantedAuthority("ROLE_" + role))
                        .forEach(authorities::add);
                }
                
                if (authorities.isEmpty()) {
                    authorities.add(new SimpleGrantedAuthority("ROLE_USER"));
                }
            } catch (Exception e) {
                log.error("Failed to convert JWT authorities", e);
                authorities.add(new SimpleGrantedAuthority("ROLE_USER"));
            }
            
            return new ArrayList<>(authorities);
        });
        
        return converter;
    }

    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration configuration = new CorsConfiguration();
        configuration.setAllowedOrigins(Arrays.asList(
            "http://localhost:3000",
            "http://localhost:3001",
            "http://localhost:3002"
        ));
        configuration.setAllowedMethods(Arrays.asList("GET", "POST", "PUT", "DELETE", "OPTIONS"));
        configuration.setAllowedHeaders(Arrays.asList("*"));
        configuration.setAllowCredentials(true);
        configuration.setMaxAge(3600L);

        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", configuration);
        return source;
    }
}