package com.fileupload.app.config;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;

@Slf4j
@Component
public class StatePreservingFilter extends OncePerRequestFilter {

 
    
    public static final String STATE_KEY_ATTRIBUTE = "OAUTH2_STATE_KEY";

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {
        
        // Check if this is the OAuth2 callback with state parameter
        if (request.getRequestURI().contains("/login/oauth2/code/")) {
            String state = request.getParameter("state");
            
            if (state != null) {
                log.info("OAuth2 callback detected with state: {}", state);
                
                try {
                    // URL decode the state
                    String decodedState = URLDecoder.decode(state, StandardCharsets.UTF_8);
                    log.info("Decoded state: {}", decodedState);
                    System.out.println(":: SecurityConfig doFilterInternal() ===  decodedState "+decodedState);
                    // Store the state in session so success handler can retrieve target URL from cache
                    HttpSession session = request.getSession();
                    session.setAttribute(STATE_KEY_ATTRIBUTE, decodedState);
                    log.info("Stored state in session for later retrieval from cache");
                } catch (Exception e) {
                    log.error("Error processing state parameter", e);
                }
            }
        }
        
        filterChain.doFilter(request, response);
    }
}