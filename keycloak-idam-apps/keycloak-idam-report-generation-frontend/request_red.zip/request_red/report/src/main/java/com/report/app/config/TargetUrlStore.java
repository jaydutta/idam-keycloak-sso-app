package com.report.app.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;

@Slf4j
@Component
public class TargetUrlStore {
    
    private final Map<String, TargetUrlEntry> cache = new ConcurrentHashMap<>();
    
    private static class TargetUrlEntry {
        String targetUrl;
        long timestamp;
        
        TargetUrlEntry(String targetUrl) {
            this.targetUrl = targetUrl;
            this.timestamp = System.currentTimeMillis();
        }
    }
    
    public void store(String stateId, String targetUrl) {
        log.info("Storing target URL for state {}: {}", stateId, targetUrl);
        cache.put(stateId, new TargetUrlEntry(targetUrl));
        cleanupOldEntries();
    }
    
    public String retrieve(String stateId) {
        TargetUrlEntry entry = cache.remove(stateId);
        if (entry != null) {
            log.info("Retrieved target URL for state {}: {}", stateId, entry.targetUrl);
            return entry.targetUrl;
        }
        log.info("No target URL found for state: {}", stateId);
        return null;
    }
    
    private void cleanupOldEntries() {
        long fiveMinutesAgo = System.currentTimeMillis() - TimeUnit.MINUTES.toMillis(5);
        cache.entrySet().removeIf(entry -> entry.getValue().timestamp < fiveMinutesAgo);
    }
}